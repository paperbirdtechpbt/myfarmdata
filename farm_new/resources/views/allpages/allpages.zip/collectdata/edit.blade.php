@extends('mainlayout')

@section('breadcrumb')
    <li><a href="#">Home</a></li>
    <li class="active">Edit Collect Data</li>
@endsection

@section('maincontent')

    <div class="row">
        <div class="col-md-12">
            <!-- <form class="form-horizontal" id="add_form" method="post" action="/schoolsetting/school"> -->
            <form class="form-horizontal" id="add_form" method="post" action="#">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title"><strong>Create</strong> Edit Data</h3>
                        <ul class="panel-controls">
                            <li><a href="{{url('unit')}}"><span class="fa fa-times"></span></a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="row" id="row_div">
                            <div class="form-group">
                                <label class="col-md-3 control-label">Select Pack</label>
                                <div class="col-md-6">
                                    <select class="form-control select" name="pack_id" id="pack_id">
                                        <option value="">select</option>
                                        <option value="true">pack1</option>
                                        <option value="false">pack2</option>
                                    </select>
                                    {{csrf_field()}}
                                    <span class="help-block">This field is required</span>
                                </div>
                            </div>
                            <div class="col-md-12" id="result_div0">
                                <div class="col-md-11">
                                    <div class="form-group">
                                        <div class="col-md-3">
                                            <div class="input-group">
                                                <span class="input-group-btn"><button class="btn btn-default" type="button">Result</button></span>
                                                <select class="form-control select" name="result_id0" id="result_id0">
                                                    <option value="">select</option>
                                                    <option value="true">result1</option>
                                                    <option value="false">result2</option>
                                                </select>
                                            </div>
                                            <span class="help-block">This field is required</span>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="input-group">
                                                <span class="input-group-btn"><button class="btn btn-default" type="button">Value</button></span>
                                                <input type="text" class="form-control" name="value0" id="value0" value="">
                                            </div>
                                            <span class="help-block">This field is required</span>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="input-group">
                                                <span class="input-group-btn"><button class="btn btn-default" type="button">Units</button></span>
                                                <select class="form-control select" name="unit_id0" id="unit_id0">
                                                    <option value="">select</option>
                                                    <option value="true">unit1</option>
                                                    <option value="false">unit2</option>
                                                </select>
                                            </div>
                                            <span class="help-block">This field is required</span>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="input-group">
                                                <span class="input-group-btn"><button class="btn btn-default" type="button">Sensor</button></span>
                                                <select class="form-control select" name="sensor_id0" id="sensor_id0">
                                                    <option value="">select</option>
                                                    <option value="true">sensor1</option>
                                                    <option value="false">sensor2</option>
                                                </select>
                                            </div>
                                            <span class="help-block">This field is required</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <button class="btn btn-default" type="button" onclick="add_row()"><i class="fa fa-pencil"></i> Add</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <button1 class="btn btn-default" onClick="$('#add_form')[0].reset();">Clear Form</button1>
                        <button class="btn btn-primary pull-right">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

@endsection

@section('javascript')
    <script>
    var count = 1;
    function add_row() {
        var html_data = '';
        html_data += '<div class="col-md-12" id="result_div'+count+'"><div class="col-md-11"><div class="form-group">';
        html_data += '<div class="col-md-3"><div class="input-group"><span class="input-group-btn"><button class="btn btn-default" type="button">Result</button></span><select class="form-control select" name="result_id'+count+'" id="result_id'+count+'"><option value="">select</option><option value="true">result1</option><option value="false">result2</option></select></div><span class="help-block">This field is required</span></div>';
        html_data += '<div class="col-md-3"><div class="input-group"><span class="input-group-btn"><button class="btn btn-default" type="button">Value</button></span><input type="text" class="form-control" name="value'+count+'" id="value'+count+'" value=""></div><span class="help-block">This field is required</span></div>';
        html_data += '<div class="col-md-3"><div class="input-group"><span class="input-group-btn"><button class="btn btn-default" type="button">Units</button></span><select class="form-control select" name="unit_id'+count+'" id="unit_id'+count+'"><option value="">select</option><option value="true">unit1</option><option value="false">unit2</option></select></div><span class="help-block">This field is required</span></div>';
        html_data += '<div class="col-md-3"><div class="input-group"><span class="input-group-btn"><button class="btn btn-default" type="button">Sensor</button></span><select class="form-control select" name="sensor_id'+count+'" id="sensor_id'+count+'"><option value="">select</option><option value="true">sensor1</option><option value="false">sensor2</option></select></div><span class="help-block">This field is required</span></div>';
        html_data += '</div></div><div class="col-md-1"><button class="btn btn-default" type="button" onclick="delete_row('+count+')"><i class="fa fa-times"></i> Remove</button></div></div>';
        $('#row_div').append(html_data);
        count++;
    }
    function delete_row(count) {
        $('#result_div'+count).hide();
    }
    var jvalidate = $("#add_form").validate({
        ignore: [],
        rules: {
            pack_id: {
                required: true,
            },
        }
    });
    // $('#name').val('test');
    // $('#email').val('a@gmail.com');
    // $('#contact').val('9865320147');
    // $('#address').val('aaa');
    </script>
@endsection
