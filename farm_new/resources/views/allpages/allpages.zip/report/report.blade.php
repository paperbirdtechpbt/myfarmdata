@extends('mainlayout')

@section('breadcrumb')
    <li><a href="#">Home</a></li>
    <li class="active">Report</li>
@endsection

@section('maincontent')

<div class="row">
    <div class="col-md-12">
        @include('common/flash_message')
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title"><strong>View</strong> Report</h3>
                <a href="{{url('collectdata/create')}}"><button class="btn btn-default pull-right">Create</button></a>
            </div>
            <div class="panel-body">
                <div class="row" style="margin-bottom: 30px;">
                    <div class="form-group">
                        <label class="col-md-3 control-label"></label>
                        <div class="col-md-6">
                            <div class="input-group">
                                <span class="input-group-btn"><button class="btn btn-default" type="button">Search Pack</button></span>
                                <select class="form-control select" name="pack_id" id="pack_id">
                                    <option value="">select</option>
                                    <option value="true">result1</option>
                                    <option value="false">result2</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                                        
                <table class="table datatable table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Pack Number</th>
                            <th>Value Units</th>
                            <th>Sensors</th>
                            <th>User Collecting</th>
                            <th>Date Time Collected</th>
                            <!-- <th>Action</th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>001</td>
                            <td>unit1</td>
                            <td>sensor1</td>
                            <td>name1</td>
                            <td>2020-01-01</td>
                            <!-- <td>
                                <a href="{{url('collectdata/1/edit')}}" class="btn btn-default" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit" style="color: #1caf9a"></i></a>
                            </td> -->
                            </td>
                            </td>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

@endsection

@section('javascript')
    <script>
        function ConfirmDelete(id){
            var token = $('#_token').val();
            var x = confirm("Are you sure you want to delete?");
            if (x){
                $.ajax({
                    url: '/schoolsetting/school/'+id,
                    data: {_method:'DELETE', _token:token },
                    type: 'POST',
                    success: function(data) {
                        var response = JSON.parse(data);
                        alert(response.message);
                        location.reload();
                    },
                    error: function() {
                        alert('something bad happened');
                    }
                });
            }
        }
        function notyConfirm(){
            noty({
                text: 'Do you want to continue?',
                layout: 'topRight',
                buttons: [
                    {addClass: 'btn btn-success btn-clean', text: 'Ok', onClick: function($noty) {
                            $noty.close();
                            noty({text: 'You clicked "Ok" button', layout: 'topRight', type: 'success'});
                        }
                    },
                    {addClass: 'btn btn-danger btn-clean', text: 'Cancel', onClick: function($noty) {
                            $noty.close();
                            noty({text: 'You clicked "Cancel" button', layout: 'topRight', type: 'error'});
                        }
                    }
                ]
            })
        }
    </script>
@endsection
